package com.example.library_management.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import org.springframework.validation.BindingResult;

import com.example.library_management.model.User;
import com.example.library_management.repository.UserRepository;

@Controller
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/")
    public String loginPage() {
        return "login";
    }

    @GetMapping("/signup")
    public String signupPage() {
        return "signup";
    }

    @PostMapping("/register")
    public String register(@Valid User user,
                           BindingResult result,
                           Model model) {

        if (result.hasErrors()) {
            return "signup";
        }

        user.setEmail(user.getEmail().toLowerCase());
        user.setRole("USER");
        userRepository.save(user);

        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String email,
                        @RequestParam String password,
                        Model model) {

        User user = userRepository.findByEmail(email.toLowerCase());

        if (user != null && user.getPassword().equals(password)) {
            return "dashboard";
        }

        model.addAttribute("error", "Invalid email or password");
        return "login";
    }
}
