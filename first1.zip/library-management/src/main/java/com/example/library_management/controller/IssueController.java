package com.example.library_management.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.example.library_management.model.Issue;
import com.example.library_management.repository.IssueRepository;

import java.time.LocalDate;

@Controller
@RequestMapping("/issue")
public class IssueController {

    @Autowired
    private IssueRepository issueRepository;

    // Open issue page
    @GetMapping
    public String issuePage() {
        return "issue-book";
    }

    // Save issue details
    @PostMapping("/save")
    public String issueBook(Issue issue) {
        issue.setIssueDate(LocalDate.now());
        issueRepository.save(issue);
        return "dashboard";
    }
}
