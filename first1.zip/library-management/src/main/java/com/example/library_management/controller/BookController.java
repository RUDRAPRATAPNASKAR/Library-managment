package com.example.library_management.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import org.springframework.validation.BindingResult;

import com.example.library_management.model.Book;
import com.example.library_management.repository.BookRepository;

@Controller
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookRepository bookRepository;

    // Open add book page
    @GetMapping("/add")
    public String addBookPage(Model model) {
        Book book = new Book();
        book.setQuantity(1);
        model.addAttribute("book", book);
        return "add-book";
    }

    // Save book
    @PostMapping("/save")
    public String saveBook(@Valid Book book,
                           BindingResult result,
                           Model model) {

        if (result.hasErrors()) {
            return "add-book";
        }

        bookRepository.save(book);
        return "redirect:/books";
    }

    // List books
    @GetMapping
    public String viewBooks(Model model) {
        model.addAttribute("books", bookRepository.findAll());
        return "books";
    }

    // ✅ DELETE BOOK (THIS WAS MISSING)
    @GetMapping("/delete/{id}")
    public String deleteBook(@PathVariable Long id) {
        bookRepository.deleteById(id);
        return "redirect:/books";
    }
}
